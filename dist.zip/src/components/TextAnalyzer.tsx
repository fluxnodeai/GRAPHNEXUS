'use client';

import React, { useState } from 'react';
import { NimEntity, NimRelation, analyzeText } from '@/lib/api/nvidia-nim';

interface TextAnalyzerProps {
  onEntitiesExtracted?: (entities: NimEntity[]) => void;
  onRelationsExtracted?: (relations: NimRelation[], entities: NimEntity[]) => void;
}

const TextAnalyzer: React.FC<TextAnalyzerProps> = ({ 
  onEntitiesExtracted,
  onRelationsExtracted
}) => {
  console.log('TextAnalyzer component rendered');
  const [text, setText] = useState('');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [entities, setEntities] = useState<NimEntity[]>([]);
  const [relations, setRelations] = useState<NimRelation[]>([]);
  const [analysisComplete, setAnalysisComplete] = useState(false);

  // Handle text change
  const handleTextChange = (e: React.ChangeEvent<HTMLTextAreaElement>) => {
    setText(e.target.value);
    // Reset results when text changes
    if (analysisComplete) {
      setEntities([]);
      setRelations([]);
      setAnalysisComplete(false);
    }
  };

  // Handle analyze button click
  const handleAnalyze = async () => {
    if (!text.trim()) {
      setError('Please enter some text to analyze');
      return;
    }

    try {
      setLoading(true);
      setError(null);
      
      // In a real app, we would call the NVIDIA NIM API
      // For demo purposes, we'll simulate the API call
      const result = await simulateNimAnalysis(text);
      
      setEntities(result.entities);
      setRelations(result.relations);
      setAnalysisComplete(true);
      
      // Call callbacks if provided
      if (onEntitiesExtracted) {
        onEntitiesExtracted(result.entities);
      }
      
      if (onRelationsExtracted) {
        onRelationsExtracted(result.relations, result.entities);
      }
    } catch (err) {
      console.error('Error analyzing text:', err);
      setError('Failed to analyze text. Please try again.');
    } finally {
      setLoading(false);
    }
  };

  // Simulate NVIDIA NIM API call
  const simulateNimAnalysis = async (text: string): Promise<{ entities: NimEntity[], relations: NimRelation[] }> => {
    // Simulate API delay
    await new Promise(resolve => setTimeout(resolve, 1500));
    
    // Simple entity extraction logic
    const entities: NimEntity[] = [];
    const relations: NimRelation[] = [];
    
    // Common entity types to look for
    const personPatterns = [
      /\b[A-Z][a-z]+ [A-Z][a-z]+\b/g, // Simple name pattern
      /\bDr\. [A-Z][a-z]+\b/g,
      /\bMr\. [A-Z][a-z]+\b/g,
      /\bMs\. [A-Z][a-z]+\b/g,
      /\bMrs\. [A-Z][a-z]+\b/g
    ];
    
    const organizationPatterns = [
      /\b[A-Z][a-zA-Z]+ (Inc|Corp|Corporation|Company|Co|Ltd)\b/g,
      /\b[A-Z][A-Z]+\b/g // Acronyms like NASA, FBI
    ];
    
    const locationPatterns = [
      /\b[A-Z][a-z]+ (City|Town|Village|County|State|Province|Country)\b/g,
      /\b(North|South|East|West) [A-Z][a-z]+\b/g
    ];
    
    // Extract entities
    let entityId = 0;
    
    // Extract persons
    personPatterns.forEach(pattern => {
      const matches = text.match(pattern);
      if (matches) {
        matches.forEach(match => {
          if (!entities.some(e => e.text === match)) {
            entities.push({
              id: (entityId++).toString(),
              text: match,
              type: 'Person',
              startIndex: text.indexOf(match),
              endIndex: text.indexOf(match) + match.length
            });
          }
        });
      }
    });
    
    // Extract organizations
    organizationPatterns.forEach(pattern => {
      const matches = text.match(pattern);
      if (matches) {
        matches.forEach(match => {
          // Skip if already found as a person
          if (!entities.some(e => e.text === match)) {
            entities.push({
              id: (entityId++).toString(),
              text: match,
              type: 'Organization',
              startIndex: text.indexOf(match),
              endIndex: text.indexOf(match) + match.length
            });
          }
        });
      }
    });
    
    // Extract locations
    locationPatterns.forEach(pattern => {
      const matches = text.match(pattern);
      if (matches) {
        matches.forEach(match => {
          // Skip if already found as a person or organization
          if (!entities.some(e => e.text === match)) {
            entities.push({
              id: (entityId++).toString(),
              text: match,
              type: 'Location',
              startIndex: text.indexOf(match),
              endIndex: text.indexOf(match) + match.length
            });
          }
        });
      }
    });
    
    // Simple relation extraction logic
    const relationPatterns = [
      { pattern: /([A-Z][a-z]+ [A-Z][a-z]+) works for ([A-Z][a-zA-Z]+ (Inc|Corp|Corporation|Company|Co|Ltd))/g, type: 'WORKS_FOR' },
      { pattern: /([A-Z][a-z]+ [A-Z][a-z]+) founded ([A-Z][a-zA-Z]+ (Inc|Corp|Corporation|Company|Co|Ltd))/g, type: 'FOUNDED' },
      { pattern: /([A-Z][a-z]+ [A-Z][a-z]+) lives in ([A-Z][a-z]+ (City|Town|Village|County|State|Province|Country))/g, type: 'LIVES_IN' },
      { pattern: /([A-Z][a-zA-Z]+ (Inc|Corp|Corporation|Company|Co|Ltd)) is located in ([A-Z][a-z]+ (City|Town|Village|County|State|Province|Country))/g, type: 'LOCATED_IN' }
    ];
    
    // Extract relations
    let relationId = 0;
    
    relationPatterns.forEach(({ pattern, type }) => {
      const regex = new RegExp(pattern);
      let match;
      
      while ((match = regex.exec(text)) !== null) {
        const sourceText = match[1];
        const targetText = match[2];
        
        const sourceEntity = entities.find(e => e.text === sourceText);
        const targetEntity = entities.find(e => e.text === targetText);
        
        if (sourceEntity && targetEntity) {
          relations.push({
            id: (relationId++).toString(),
            type,
            sourceId: sourceEntity.id,
            targetId: targetEntity.id,
            text: match[0]
          });
        }
      }
    });
    
    return { entities, relations };
  };

  // Get entity type badge color
  const getEntityTypeBadgeClass = (type: string): string => {
    switch (type) {
      case 'Person':
        return 'badge-blue';
      case 'Organization':
        return 'badge-red';
      case 'Location':
        return 'badge-yellow';
      case 'Event':
        return 'badge-green';
      case 'Product':
        return 'badge-purple';
      default:
        return '';
    }
  };

  return (
    <div className="card text-analyzer-container">
      <div className="card-header">
        <h2 className="card-title">
          <span className="card-title-icon">
            <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
              <path d="M9.663 17h4.673M12 3v1m6.364 1.636l-.707.707M21 12h-1M4 12H3m3.343-5.657l-.707-.707m2.828 9.9a5 5 0 117.072 0l-.548.547A3.374 3.374 0 0014 18.469V19a2 2 0 11-4 0v-.531c0-.895-.356-1.754-.988-2.386l-.548-.547z"></path>
            </svg>
          </span>
          NVIDIA NIM Text Analyzer
        </h2>
      </div>
      
      <div className="mb-4">
        <p className="text-secondary text-sm mb-4">
          Enter text to extract entities and relationships using NVIDIA NIM's Named Entity Recognition and Relation Extraction capabilities.
        </p>
        
        <div className="form-group">
          <label htmlFor="text-input" className="form-label">Text to Analyze</label>
          <textarea
            id="text-input"
            className="form-input form-textarea"
            value={text}
            onChange={handleTextChange}
            placeholder="Enter text to analyze (e.g., 'John Smith works for Acme Inc in New York City.')"
            rows={5}
            disabled={loading}
          ></textarea>
        </div>
        
        {error && (
          <div className="text-error text-sm mb-4">
            {error}
          </div>
        )}
        
        <div className="flex justify-end">
          <button
            className="btn btn-primary"
            onClick={handleAnalyze}
            disabled={loading || !text.trim()}
          >
            {loading ? (
              <>
                <div className="loading-spinner w-4 h-4 mr-2"></div>
                Analyzing...
              </>
            ) : (
              <>
                <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4 mr-2" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9.663 17h4.673M12 3v1m6.364 1.636l-.707.707M21 12h-1M4 12H3m3.343-5.657l-.707-.707m2.828 9.9a5 5 0 117.072 0l-.548.547A3.374 3.374 0 0014 18.469V19a2 2 0 11-4 0v-.531c0-.895-.356-1.754-.988-2.386l-.548-.547z" />
                </svg>
                Analyze Text
              </>
            )}
          </button>
        </div>
      </div>
      
      {analysisComplete && (
        <div className="mt-6">
          <div className="terminal">
            <div className="terminal-header">
              <div className="terminal-title">Analysis Results</div>
            </div>
            <div className="terminal-content">
              <div className="mb-4">
                <div className="text-accent mb-2">Entities Extracted:</div>
                {entities.length > 0 ? (
                  <div className="space-y-2">
                    {entities.map(entity => (
                      <div key={entity.id} className="flex items-center">
                        <span className={`badge ${getEntityTypeBadgeClass(entity.type)} mr-2`}>
                          {entity.type}
                        </span>
                        <span>{entity.text}</span>
                      </div>
                    ))}
                  </div>
                ) : (
                  <div className="text-secondary">No entities found</div>
                )}
              </div>
              
              <div>
                <div className="text-accent mb-2">Relationships Extracted:</div>
                {relations.length > 0 ? (
                  <div className="space-y-2">
                    {relations.map(relation => {
                      const sourceEntity = entities.find(e => e.id === relation.sourceId);
                      const targetEntity = entities.find(e => e.id === relation.targetId);
                      
                      return (
                        <div key={relation.id} className="text-secondary">
                          <span className={`badge ${getEntityTypeBadgeClass(sourceEntity?.type || '')}`}>
                            {sourceEntity?.text}
                          </span>
                          {' '}
                          <span className="text-accent">
                            {relation.type}
                          </span>
                          {' '}
                          <span className={`badge ${getEntityTypeBadgeClass(targetEntity?.type || '')}`}>
                            {targetEntity?.text}
                          </span>
                        </div>
                      );
                    })}
                  </div>
                ) : (
                  <div className="text-secondary">No relationships found</div>
                )}
              </div>
            </div>
          </div>
          
          <div className="mt-4 flex justify-end">
            <button
              className="btn btn-success"
              onClick={() => {
                if (entities.length > 0 || relations.length > 0) {
                  // In a real app, we would add these to the graph
                  // For demo purposes, we'll just show a notification
                  const notification = document.createElement('div');
                  notification.className = 'fixed bottom-4 right-4 bg-green-500 text-white p-4 rounded-lg shadow-lg';
                  notification.innerHTML = `Added ${entities.length} entities and ${relations.length} relationships to the graph`;
                  document.body.appendChild(notification);
                  
                  setTimeout(() => {
                    notification.remove();
                  }, 3000);
                }
              }}
              disabled={entities.length === 0 && relations.length === 0}
            >
              <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4 mr-2" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 6v6m0 0v6m0-6h6m-6 0H6" />
              </svg>
              Add to Graph
            </button>
          </div>
        </div>
      )}
      
      <div className="mt-4 text-xs text-secondary">
        <p>
          <strong>Note:</strong> This is a simulated demo of NVIDIA NIM's Named Entity Recognition and Relation Extraction capabilities.
          In a production environment, this would connect to NVIDIA's NIM API for more accurate results.
        </p>
      </div>
    </div>
  );
};

export default TextAnalyzer;
