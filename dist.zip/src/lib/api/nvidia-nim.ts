import axios from 'axios';

// NVIDIA NIM API client
// In a real project, these would be environment variables
const NIM_API_BASE_URL = process.env.NEXT_PUBLIC_NIM_API_BASE_URL || 'https://api.nim.nvidia.com';
const NIM_API_KEY = process.env.NIM_API_KEY || 'your-nim-api-key';

// Create axios instance with default config
const nimClient = axios.create({
  baseURL: NIM_API_BASE_URL,
  headers: {
    'Content-Type': 'application/json',
    'Authorization': `Bearer ${NIM_API_KEY}`
  }
});

// Entity types
export interface NimEntity {
  id: string;
  text: string;
  type: string;
  startIndex: number;
  endIndex: number;
  confidence?: number;
}

// Relation types
export interface NimRelation {
  id: string;
  type: string;
  sourceId: string; // ID of source entity
  targetId: string; // ID of target entity
  text: string;
  confidence?: number;
}

// Response types
export interface NerResponse {
  entities: NimEntity[];
}

export interface RelationExtractionResponse {
  relations: NimRelation[];
  entities: NimEntity[];
}

// Analyze text to extract entities and relations
export const analyzeText = async (text: string): Promise<{
  entities: NimEntity[];
  relations: NimRelation[];
}> => {
  try {
    // In a real implementation, you would call the NVIDIA NIM API
    // Here we're simulating the API call
    return await simulateNimAnalysis(text);
  } catch (error) {
    console.error('Error analyzing text with NVIDIA NIM:', error);
    throw error;
  }
};

// NVIDIA NIM API operations
export const nimOperations = {
  // Named Entity Recognition
  extractEntities: async (text: string): Promise<NerResponse> => {
    try {
      // This is a mock endpoint - replace with actual NVIDIA NIM endpoint
      const response = await nimClient.post('/v1/ner', {
        text
      });
      return response.data;
    } catch (error) {
      console.error('Error calling NVIDIA NIM NER API:', error);
      throw error;
    }
  },
  
  // Relation Extraction
  extractRelations: async (text: string): Promise<RelationExtractionResponse> => {
    try {
      // This is a mock endpoint - replace with actual NVIDIA NIM endpoint
      const response = await nimClient.post('/v1/relation-extraction', {
        text
      });
      return response.data;
    } catch (error) {
      console.error('Error calling NVIDIA NIM Relation Extraction API:', error);
      throw error;
    }
  },
  
  // Process text to extract entities and relations
  processText: async (text: string): Promise<{
    entities: NimEntity[];
    relations: NimRelation[];
  }> => {
    try {
      // In a real implementation, you might call separate endpoints
      // Here we're simulating a combined call
      const response = await nimClient.post('/v1/process-text', {
        text
      });
      return response.data;
    } catch (error) {
      console.error('Error processing text with NVIDIA NIM:', error);
      
      // For demo purposes, return mock data if API is not available
      return simulateNimAnalysis(text);
    }
  }
};

// Simulate NVIDIA NIM API call
export const simulateNimAnalysis = async (text: string): Promise<{ 
  entities: NimEntity[], 
  relations: NimRelation[] 
}> => {
  // Simulate API delay
  await new Promise(resolve => setTimeout(resolve, 1000));
  
  // Simple entity extraction logic
  const entities: NimEntity[] = [];
  const relations: NimRelation[] = [];
  
  // Common entity types to look for
  const personPatterns = [
    /\b[A-Z][a-z]+ [A-Z][a-z]+\b/g, // Simple name pattern
    /\bDr\. [A-Z][a-z]+\b/g,
    /\bMr\. [A-Z][a-z]+\b/g,
    /\bMs\. [A-Z][a-z]+\b/g,
    /\bMrs\. [A-Z][a-z]+\b/g
  ];
  
  const organizationPatterns = [
    /\b[A-Z][a-zA-Z]+ (Inc|Corp|Corporation|Company|Co|Ltd)\b/g,
    /\b[A-Z][A-Z]+\b/g // Acronyms like NASA, FBI
  ];
  
  const locationPatterns = [
    /\b[A-Z][a-z]+ (City|Town|Village|County|State|Province|Country)\b/g,
    /\b(North|South|East|West) [A-Z][a-z]+\b/g
  ];
  
  // Extract entities
  let entityId = 0;
  
  // Extract persons
  personPatterns.forEach(pattern => {
    const matches = text.match(pattern);
    if (matches) {
      matches.forEach(match => {
        if (!entities.some(e => e.text === match)) {
          entities.push({
            id: (entityId++).toString(),
            text: match,
            type: 'Person',
            startIndex: text.indexOf(match),
            endIndex: text.indexOf(match) + match.length
          });
        }
      });
    }
  });
  
  // Extract organizations
  organizationPatterns.forEach(pattern => {
    const matches = text.match(pattern);
    if (matches) {
      matches.forEach(match => {
        // Skip if already found as a person
        if (!entities.some(e => e.text === match)) {
          entities.push({
            id: (entityId++).toString(),
            text: match,
            type: 'Organization',
            startIndex: text.indexOf(match),
            endIndex: text.indexOf(match) + match.length
          });
        }
      });
    }
  });
  
  // Extract locations
  locationPatterns.forEach(pattern => {
    const matches = text.match(pattern);
    if (matches) {
      matches.forEach(match => {
        // Skip if already found as a person or organization
        if (!entities.some(e => e.text === match)) {
          entities.push({
            id: (entityId++).toString(),
            text: match,
            type: 'Location',
            startIndex: text.indexOf(match),
            endIndex: text.indexOf(match) + match.length
          });
        }
      });
    }
  });
  
  // Simple relation extraction logic
  const relationPatterns = [
    { pattern: /([A-Z][a-z]+ [A-Z][a-z]+) works for ([A-Z][a-zA-Z]+ (Inc|Corp|Corporation|Company|Co|Ltd))/g, type: 'WORKS_FOR' },
    { pattern: /([A-Z][a-z]+ [A-Z][a-z]+) founded ([A-Z][a-zA-Z]+ (Inc|Corp|Corporation|Company|Co|Ltd))/g, type: 'FOUNDED' },
    { pattern: /([A-Z][a-z]+ [A-Z][a-z]+) lives in ([A-Z][a-z]+ (City|Town|Village|County|State|Province|Country))/g, type: 'LIVES_IN' },
    { pattern: /([A-Z][a-zA-Z]+ (Inc|Corp|Corporation|Company|Co|Ltd)) is located in ([A-Z][a-z]+ (City|Town|Village|County|State|Province|Country))/g, type: 'LOCATED_IN' }
  ];
  
  // Extract relations
  let relationId = 0;
  
  relationPatterns.forEach(({ pattern, type }) => {
    const regex = new RegExp(pattern);
    let match;
    
    while ((match = regex.exec(text)) !== null) {
      const sourceText = match[1];
      const targetText = match[2];
      
      const sourceEntity = entities.find(e => e.text === sourceText);
      const targetEntity = entities.find(e => e.text === targetText);
      
      if (sourceEntity && targetEntity) {
        relations.push({
          id: (relationId++).toString(),
          type,
          sourceId: sourceEntity.id,
          targetId: targetEntity.id,
          text: match[0]
        });
      }
    }
  });
  
  return { entities, relations };
};
