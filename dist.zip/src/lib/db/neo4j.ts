import neo4j, { Driver, Session } from 'neo4j-driver';

// Initialize Neo4j driver
// In a real project, these would be environment variables
const neo4jUri = process.env.NEO4J_URI || 'neo4j://localhost:7687';
const neo4jUser = process.env.NEO4J_USER || 'neo4j';
const neo4jPassword = process.env.NEO4J_PASSWORD || 'password';

let driver: Driver;

// Get Neo4j driver instance
export function getDriver(): Driver {
  if (!driver) {
    driver = neo4j.driver(
      neo4jUri,
      neo4j.auth.basic(neo4jUser, neo4jPassword)
    );
  }
  return driver;
}

// Get a Neo4j session
export function getSession(): Session {
  return getDriver().session();
}

// Close the driver when the application shuts down
export async function closeDriver(): Promise<void> {
  if (driver) {
    await driver.close();
  }
}

// Graph data types
export interface GraphNode {
  id: string;
  labels: string[];
  properties: Record<string, any>;
}

export interface GraphRelationship {
  id: string;
  type: string;
  startNodeId: string;
  endNodeId: string;
  properties: Record<string, any>;
}

export interface GraphData {
  nodes: GraphNode[];
  relationships: GraphRelationship[];
}

// Neo4j operations
export const graphOperations = {
  // Get all nodes and relationships
  getGraphData: async (): Promise<GraphData> => {
    const session = getSession();
    try {
      const result = await session.run(`
        MATCH (n)
        OPTIONAL MATCH (n)-[r]->(m)
        RETURN n, r, m
      `);
      
      const nodes = new Map<string, GraphNode>();
      const relationships: GraphRelationship[] = [];
      
      result.records.forEach(record => {
        // Process nodes
        const startNode = record.get('n');
        if (startNode) {
          const id = startNode.identity.toString();
          if (!nodes.has(id)) {
            nodes.set(id, {
              id,
              labels: startNode.labels,
              properties: startNode.properties
            });
          }
        }
        
        // Process end nodes
        const endNode = record.get('m');
        if (endNode) {
          const id = endNode.identity.toString();
          if (!nodes.has(id)) {
            nodes.set(id, {
              id,
              labels: endNode.labels,
              properties: endNode.properties
            });
          }
        }
        
        // Process relationships
        const relationship = record.get('r');
        if (relationship) {
          relationships.push({
            id: relationship.identity.toString(),
            type: relationship.type,
            startNodeId: relationship.start.toString(),
            endNodeId: relationship.end.toString(),
            properties: relationship.properties
          });
        }
      });
      
      return {
        nodes: Array.from(nodes.values()),
        relationships
      };
    } finally {
      await session.close();
    }
  },
  
  // Create a new entity node
  createEntityNode: async (entity: { name: string; type: string; properties: Record<string, any> }): Promise<GraphNode> => {
    const session = getSession();
    try {
      const result = await session.run(
        `
        CREATE (n:Entity:${entity.type} {name: $name, properties: $properties})
        RETURN n
        `,
        { name: entity.name, properties: entity.properties }
      );
      
      const node = result.records[0].get('n');
      return {
        id: node.identity.toString(),
        labels: node.labels,
        properties: node.properties
      };
    } finally {
      await session.close();
    }
  },
  
  // Create a relationship between two entities
  createRelationship: async (
    startNodeId: string,
    endNodeId: string,
    type: string,
    properties: Record<string, any> = {}
  ): Promise<GraphRelationship> => {
    const session = getSession();
    try {
      const result = await session.run(
        `
        MATCH (a), (b)
        WHERE id(a) = $startNodeId AND id(b) = $endNodeId
        CREATE (a)-[r:${type} $properties]->(b)
        RETURN r
        `,
        { startNodeId: parseInt(startNodeId), endNodeId: parseInt(endNodeId), properties }
      );
      
      const relationship = result.records[0].get('r');
      return {
        id: relationship.identity.toString(),
        type: relationship.type,
        startNodeId: relationship.start.toString(),
        endNodeId: relationship.end.toString(),
        properties: relationship.properties
      };
    } finally {
      await session.close();
    }
  }
};
