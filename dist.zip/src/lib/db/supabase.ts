import { createClient } from '@supabase/supabase-js';

// Initialize Supabase client
// In a real project, these would be environment variables
const supabaseUrl = process.env.NEXT_PUBLIC_SUPABASE_URL || 'https://your-supabase-url.supabase.co';
const supabaseKey = process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY || 'your-supabase-anon-key';

export const supabase = createClient(supabaseUrl, supabaseKey);

// Entity types for TypeScript
export interface Entity {
  id: string;
  name: string;
  type: string;
  description: string;
  properties: Record<string, any>;
  created_at: string;
}

// Supabase table operations
export const entityOperations = {
  // Get all entities
  getEntities: async (): Promise<Entity[]> => {
    const { data, error } = await supabase
      .from('entities')
      .select('*')
      .order('created_at', { ascending: false });
    
    if (error) throw error;
    return data || [];
  },
  
  // Get entity by ID
  getEntityById: async (id: string): Promise<Entity | null> => {
    const { data, error } = await supabase
      .from('entities')
      .select('*')
      .eq('id', id)
      .single();
    
    if (error) throw error;
    return data;
  },
  
  // Create new entity
  createEntity: async (entity: Omit<Entity, 'id' | 'created_at'>): Promise<Entity> => {
    const { data, error } = await supabase
      .from('entities')
      .insert([entity])
      .select()
      .single();
    
    if (error) throw error;
    return data;
  },
  
  // Update entity
  updateEntity: async (id: string, updates: Partial<Entity>): Promise<Entity> => {
    const { data, error } = await supabase
      .from('entities')
      .update(updates)
      .eq('id', id)
      .select()
      .single();
    
    if (error) throw error;
    return data;
  },
  
  // Delete entity
  deleteEntity: async (id: string): Promise<void> => {
    const { error } = await supabase
      .from('entities')
      .delete()
      .eq('id', id);
    
    if (error) throw error;
  }
};
