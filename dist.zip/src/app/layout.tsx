import type { Metadata } from "next";
import { Inter } from "next/font/google";
import "./globals.css";
import Link from "next/link";

const inter = Inter({ subsets: ["latin"] });

export const metadata: Metadata = {
  title: "GraphNexus - Knowledge Graph Visualization",
  description: "Interactive knowledge graph visualization with NVIDIA NIM, Neo4j, and Supabase",
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="en">
      <body>
        <div className="app-container">
          <header className="app-header">
            <div className="w-full flex justify-between items-center">
              <div className="app-logo">
                <span className="app-logo-icon">
                  <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                    <circle cx="12" cy="12" r="10"></circle>
                    <path d="M9.09 9a3 3 0 0 1 5.83 1c0 2-3 3-3 3"></path>
                    <line x1="12" y1="17" x2="12.01" y2="17"></line>
                  </svg>
                </span>
                GraphNexus
              </div>
              <nav className="app-nav">
                <Link href="/" className="app-nav-link">
                  Home
                </Link>
                <Link href="/graph" className="app-nav-link">
                  Knowledge Graph
                </Link>
                <Link href="/entities" className="app-nav-link">
                  Entity Management
                </Link>
              </nav>
            </div>
          </header>
          <main className="app-main">
            {children}
          </main>
          <footer className="app-footer">
            <div className="flex justify-between items-center w-full">
              <div>
                GraphNexus v0.1.0 - Powered by NVIDIA NIM, Neo4j, and Supabase
              </div>
              <div className="flex gap-4">
                <a href="#" className="text-secondary text-sm">Documentation</a>
                <a href="#" className="text-secondary text-sm">GitHub</a>
              </div>
            </div>
          </footer>
        </div>
      </body>
    </html>
  );
}
