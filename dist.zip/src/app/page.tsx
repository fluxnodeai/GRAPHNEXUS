import Link from "next/link";

export default function Home() {
  return (
    <div>
      <section className="mb-8">
        <div className="card">
          <div className="card-header">
            <h2 className="card-title">
              <span className="card-title-icon">
                <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                  <circle cx="12" cy="12" r="10"></circle>
                  <path d="M9.09 9a3 3 0 0 1 5.83 1c0 2-3 3-3 3"></path>
                  <line x1="12" y1="17" x2="12.01" y2="17"></line>
                </svg>
              </span>
              Welcome to GraphNexus
            </h2>
          </div>
          <p className="mb-4">
            GraphNexus is an interactive knowledge graph visualization platform powered by NVIDIA NIM, Neo4j, and Supabase.
            Explore entity relationships, analyze text for named entities, and visualize complex networks with ease.
          </p>
          <div className="terminal">
            <div className="terminal-header">
              <div className="terminal-title">Quick Start</div>
            </div>
            <div className="terminal-content">
              <div>
                <span className="terminal-prompt">$</span>
                <span className="terminal-command"> npm install</span>
              </div>
              <div className="terminal-output">Installing dependencies...</div>
              <div>
                <span className="terminal-prompt">$</span>
                <span className="terminal-command"> npm run dev</span>
              </div>
              <div className="terminal-output">Starting development server...</div>
              <div className="terminal-output text-success">✓ Ready in 1.2s</div>
              <div className="terminal-output">- Local: http://localhost:3000</div>
            </div>
          </div>
        </div>
      </section>

      <section>
        <div className="grid">
          <div className="card">
            <div className="card-header">
              <h2 className="card-title">
                <span className="card-title-icon">
                  <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                    <path d="M4 5a1 1 0 011-1h14a1 1 0 011 1v2a1 1 0 01-1 1H5a1 1 0 01-1-1V5zM4 13a1 1 0 011-1h6a1 1 0 011 1v6a1 1 0 01-1 1H5a1 1 0 01-1-1v-6zM16 13a1 1 0 011-1h2a1 1 0 011 1v6a1 1 0 01-1 1h-2a1 1 0 01-1-1v-6z"></path>
                  </svg>
                </span>
                Knowledge Graph
              </h2>
            </div>
            <p className="mb-4">
              Explore the interactive knowledge graph visualization powered by Cytoscape.js and Neo4j.
              Visualize entities and their relationships in an intuitive network diagram.
            </p>
            <Link href="/graph" className="btn btn-primary">
              <span className="btn-icon">
                <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                  <path d="M5 12h14"></path>
                  <path d="M12 5l7 7-7 7"></path>
                </svg>
              </span>
              Explore Graph
            </Link>
          </div>

          <div className="card">
            <div className="card-header">
              <h2 className="card-title">
                <span className="card-title-icon">
                  <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                    <path d="M19 11H5m14 0a2 2 0 012 2v6a2 2 0 01-2 2H5a2 2 0 01-2-2v-6a2 2 0 012-2m14 0V9a2 2 0 00-2-2M5 11V9a2 2 0 012-2m0 0V5a2 2 0 012-2h6a2 2 0 012 2v2M7 7h10"></path>
                  </svg>
                </span>
                Entity Management
              </h2>
            </div>
            <p className="mb-4">
              View and manage entities stored in Supabase with NVIDIA NIM integration.
              Extract entities and relationships from text using AI-powered analysis.
            </p>
            <Link href="/entities" className="btn btn-primary">
              <span className="btn-icon">
                <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                  <path d="M5 12h14"></path>
                  <path d="M12 5l7 7-7 7"></path>
                </svg>
              </span>
              Manage Entities
            </Link>
          </div>

          <div className="card">
            <div className="card-header">
              <h2 className="card-title">
                <span className="card-title-icon">
                  <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                    <path d="M9.663 17h4.673M12 3v1m6.364 1.636l-.707.707M21 12h-1M4 12H3m3.343-5.657l-.707-.707m2.828 9.9a5 5 0 117.072 0l-.548.547A3.374 3.374 0 0014 18.469V19a2 2 0 11-4 0v-.531c0-.895-.356-1.754-.988-2.386l-.548-.547z"></path>
                  </svg>
                </span>
                NVIDIA NIM Integration
              </h2>
            </div>
            <p className="mb-4">
              Leverage NVIDIA's Named Entity Recognition and Relation Extraction capabilities
              to automatically identify entities and relationships in text.
            </p>
            <div className="terminal">
              <div className="terminal-header">
                <div className="terminal-title">Example API Call</div>
              </div>
              <div className="terminal-content">
                <div className="terminal-output">
                  <span className="text-accent">POST</span> /api/nvidia-nim/analyze
                </div>
                <div className="terminal-output">
                  {`{
  "text": "Apple was founded by Steve Jobs in California."
}`}
                </div>
              </div>
            </div>
          </div>

          <div className="card">
            <div className="card-header">
              <h2 className="card-title">
                <span className="card-title-icon">
                  <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                    <path d="M5 12h14M5 12a2 2 0 01-2-2V6a2 2 0 012-2h14a2 2 0 012 2v4a2 2 0 01-2 2M5 12a2 2 0 00-2 2v4a2 2 0 002 2h14a2 2 0 002-2v-4a2 2 0 00-2-2m-2-4h.01M17 16h.01"></path>
                  </svg>
                </span>
                Supabase Integration
              </h2>
            </div>
            <p className="mb-4">
              Store and manage structured entity data in Supabase, a powerful PostgreSQL-based
              backend-as-a-service platform.
            </p>
            <div className="flex gap-2">
              <span className="badge badge-blue">PostgreSQL</span>
              <span className="badge badge-green">Real-time</span>
              <span className="badge badge-purple">Auth</span>
              <span className="badge badge-yellow">Storage</span>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
}
