'use client';

import React, { useEffect, useState } from 'react';
import Link from 'next/link';
import GraphVisualization from '@/components/GraphVisualization';
import EntityDetail from '@/components/EntityDetail';
import TextAnalyzer from '@/components/TextAnalyzer';
import { graphOperations, GraphData, GraphNode } from '@/lib/db/neo4j';
import { entityOperations, Entity } from '@/lib/db/supabase';
import { generateSyntheticDataset } from '@/lib/utils/synthetic-data';
import { NimEntity, NimRelation } from '@/lib/api/nvidia-nim';

export default function GraphPage() {
  const [graphData, setGraphData] = useState<GraphData | null>(null);
  const [selectedEntity, setSelectedEntity] = useState<Entity | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [nodeCount, setNodeCount] = useState(20);
  const [showAnalyzer, setShowAnalyzer] = useState(false);

  // Load graph data
  useEffect(() => {
    const loadGraphData = async () => {
      try {
        setLoading(true);
        setError(null);
        
        console.log('Generating synthetic data with node count:', nodeCount);
        
        // In a real app, we would fetch from Neo4j
        // For demo purposes, we'll generate synthetic data
        const syntheticData = generateSyntheticDataset(nodeCount);
        
        console.log('Synthetic data generated:', syntheticData);
        
        // Convert to GraphData format
        const graphData: GraphData = {
          nodes: syntheticData.nodes,
          relationships: syntheticData.relationships.map((rel, index) => ({
            ...rel,
            id: index.toString()
          }))
        };
        
        console.log('Setting graph data:', graphData);
        setGraphData(graphData);
        
        // Simulate loading delay
        setTimeout(() => {
          setLoading(false);
        }, 1000);
      } catch (err) {
        console.error('Error loading graph data:', err);
        setError(`Failed to load graph data: ${err instanceof Error ? err.message : String(err)}`);
        setLoading(false);
      }
    };
    
    loadGraphData();
  }, [nodeCount]);

  // Handle node click in the graph
  const handleNodeClick = async (nodeId: string) => {
    if (!graphData) return;
    
    try {
      // Find the node in the graph data
      const node = graphData.nodes.find(n => n.id === nodeId);
      
      if (node) {
        // In a real app, we would fetch from Supabase
        // For demo purposes, we'll create an entity from the node
        const entity: Entity = {
          id: node.id,
          name: node.properties.name || `Node ${node.id}`,
          type: node.labels[1] || 'Entity',
          description: `This is a ${node.labels[1] || 'Entity'} node in the knowledge graph.`,
          properties: node.properties,
          created_at: new Date().toISOString()
        };
        
        setSelectedEntity(entity);
      }
    } catch (err) {
      console.error('Error fetching entity details:', err);
    }
  };

  // Handle entities extracted from text
  const handleEntitiesExtracted = (entities: NimEntity[]) => {
    console.log('Entities extracted:', entities);
    // In a real app, we would add these entities to the graph
    
    // For demo purposes, we'll show a notification
    const notification = document.createElement('div');
    notification.className = 'fixed bottom-4 right-4 bg-green-500 text-white p-4 rounded-lg shadow-lg';
    notification.innerHTML = `Extracted ${entities.length} entities from text`;
    document.body.appendChild(notification);
    
    setTimeout(() => {
      notification.remove();
    }, 3000);
  };

  // Handle relations extracted from text
  const handleRelationsExtracted = (relations: NimRelation[], entities: NimEntity[]) => {
    console.log('Relations extracted:', relations);
    // In a real app, we would add these relations to the graph
    
    // For demo purposes, we'll show a notification
    const notification = document.createElement('div');
    notification.className = 'fixed bottom-4 right-4 bg-blue-500 text-white p-4 rounded-lg shadow-lg';
    notification.innerHTML = `Extracted ${relations.length} relationships from text`;
    document.body.appendChild(notification);
    
    setTimeout(() => {
      notification.remove();
    }, 3000);
  };

  // Regenerate graph data
  const handleRegenerateGraph = () => {
    setLoading(true);
    const newNodeCount = Math.max(5, Math.min(50, nodeCount));
    setNodeCount(newNodeCount);
  };

  return (
    <div className="w-full">
      <div className="flex flex-wrap justify-between items-center mb-6">
        <div>
          <h1 className="text-2xl font-bold mb-2">Knowledge Graph Explorer</h1>
          <p className="text-secondary">
            Interactive visualization of entities and their relationships
          </p>
        </div>
        <div className="flex flex-wrap gap-2 mt-2 sm:mt-0">
          <div className="flex items-center">
            <label htmlFor="nodeCount" className="text-sm mr-2">Nodes:</label>
            <input
              id="nodeCount"
              type="number"
              min="5"
              max="50"
              value={nodeCount}
              onChange={(e) => setNodeCount(parseInt(e.target.value) || 20)}
              className="form-input w-16"
            />
          </div>
          <button
            onClick={handleRegenerateGraph}
            className="btn btn-primary"
            disabled={loading}
          >
            <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4 mr-2" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 4v5h.582m15.356 2A8.001 8.001 0 004.582 9m0 0H9m11 11v-5h-.581m0 0a8.003 8.003 0 01-15.357-2m15.357 2H15" />
            </svg>
            Regenerate
          </button>
          <button
            onClick={() => setShowAnalyzer(!showAnalyzer)}
            className="btn"
          >
            <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4 mr-2" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9.663 17h4.673M12 3v1m6.364 1.636l-.707.707M21 12h-1M4 12H3m3.343-5.657l-.707-.707m2.828 9.9a5 5 0 117.072 0l-.548.547A3.374 3.374 0 0014 18.469V19a2 2 0 11-4 0v-.531c0-.895-.356-1.754-.988-2.386l-.548-.547z" />
            </svg>
            {showAnalyzer ? 'Hide Analyzer' : 'Show Analyzer'}
          </button>
        </div>
      </div>

      {error && (
        <div className="card bg-red-900 border-red-800 mb-6">
          <div className="flex items-center">
            <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6 text-red-500 mr-3" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 8v4m0 4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
            </svg>
            <div>
              <h3 className="font-bold text-red-500">Error</h3>
              <p className="text-red-300">{error}</p>
            </div>
          </div>
        </div>
      )}

      <div className="grid grid-cols-1 lg:grid-cols-4 xl:grid-cols-5 gap-4 md:gap-6 w-full">
        <div className="lg:col-span-3 xl:col-span-4 space-y-4 md:space-y-6 w-full">
          {loading ? (
            <div className="card">
              <div className="card-header">
                <h2 className="card-title">
                  <span className="card-title-icon">
                    <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                      <path d="M4 5a1 1 0 011-1h14a1 1 0 011 1v2a1 1 0 01-1 1H5a1 1 0 01-1-1V5zM4 13a1 1 0 011-1h6a1 1 0 011 1v6a1 1 0 01-1 1H5a1 1 0 01-1-1v-6zM16 13a1 1 0 011-1h2a1 1 0 011 1v6a1 1 0 01-1 1h-2a1 1 0 01-1-1v-6z"></path>
                    </svg>
                  </span>
                  Knowledge Graph Visualization
                </h2>
              </div>
              <div className="cytoscape-container flex items-center justify-center">
                <div className="text-center">
                  <div className="loading-spinner"></div>
                  <p className="mt-4">Loading graph data...</p>
                  <p className="text-sm text-secondary mt-2">Generating {nodeCount} nodes and relationships</p>
                </div>
              </div>
            </div>
          ) : graphData ? (
            <GraphVisualization 
              graphData={graphData} 
              onNodeClick={handleNodeClick}
            />
          ) : (
            <div className="card">
              <div className="card-header">
                <h2 className="card-title">
                  <span className="card-title-icon">
                    <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                      <path d="M4 5a1 1 0 011-1h14a1 1 0 011 1v2a1 1 0 01-1 1H5a1 1 0 01-1-1V5zM4 13a1 1 0 011-1h6a1 1 0 011 1v6a1 1 0 01-1 1H5a1 1 0 01-1-1v-6zM16 13a1 1 0 011-1h2a1 1 0 011 1v6a1 1 0 01-1 1h-2a1 1 0 01-1-1v-6z"></path>
                    </svg>
                  </span>
                  Knowledge Graph Visualization
                </h2>
              </div>
              <div className="cytoscape-container flex items-center justify-center">
                <div className="text-center">
                  <svg xmlns="http://www.w3.org/2000/svg" className="h-16 w-16 mx-auto text-secondary mb-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9.172 16.172a4 4 0 015.656 0M9 10h.01M15 10h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
                  </svg>
                  <p className="text-secondary">No graph data available</p>
                  <button
                    onClick={handleRegenerateGraph}
                    className="btn btn-primary mt-4"
                  >
                    Generate Graph Data
                  </button>
                </div>
              </div>
            </div>
          )}
          
          {showAnalyzer && (
            <TextAnalyzer 
              onEntitiesExtracted={handleEntitiesExtracted}
              onRelationsExtracted={handleRelationsExtracted}
            />
          )}
        </div>
        
        <div className="space-y-4 md:space-y-6 w-full">
          <EntityDetail 
            entity={selectedEntity} 
            loading={loading && !selectedEntity}
          />
          
          {!selectedEntity && !loading && (
            <div className="card info-card">
              <div className="card-header">
                <h2 className="card-title">
                  <span className="card-title-icon">
                    <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                      <circle cx="11" cy="11" r="8"></circle>
                      <line x1="21" y1="21" x2="16.65" y2="16.65"></line>
                    </svg>
                  </span>
                  Graph Information
                </h2>
              </div>
              
              <h3 className="text-lg font-medium mb-2">Node Selection</h3>
              <p className="text-secondary mb-4">
                Click on any node in the graph to view its details here.
              </p>
              
              <div className="graph-stats">
                <div className="stat-item">
                  <div className="stat-value">{graphData?.nodes.length || 0}</div>
                  <div className="stat-label">Nodes</div>
                </div>
                <div className="stat-item">
                  <div className="stat-value">{graphData?.relationships.length || 0}</div>
                  <div className="stat-label">Relationships</div>
                </div>
                <div className="stat-item">
                  <div className="stat-value">{Array.from(new Set(graphData?.nodes.map(node => node.labels[1]) || [])).length}</div>
                  <div className="stat-label">Entity Types</div>
                </div>
              </div>
              
              <div className="mt-4">
                <h4 className="text-sm font-bold text-secondary mb-2">Entity Types:</h4>
                <div className="flex flex-wrap gap-2">
                  {Array.from(new Set(graphData?.nodes.map(node => node.labels[1]) || [])).map((type, index) => (
                    <span key={index} className={`badge badge-${type === 'Person' ? 'blue' : type === 'Organization' ? 'red' : type === 'Location' ? 'yellow' : 'purple'}`}>
                      {type}
                    </span>
                  ))}
                </div>
              </div>
            </div>
          )}
          
          <div className="card info-card">
            <div className="card-header">
              <h2 className="card-title">
                <span className="card-title-icon">
                  <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                    <path d="M9.663 17h4.673M12 3v1m6.364 1.636l-.707.707M21 12h-1M4 12H3m3.343-5.657l-.707-.707m2.828 9.9a5 5 0 117.072 0l-.548.547A3.374 3.374 0 0014 18.469V19a2 2 0 11-4 0v-.531c0-.895-.356-1.754-.988-2.386l-.548-.547z"></path>
                  </svg>
                </span>
                Quick Tips
              </h2>
            </div>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-sm">
              <div className="flex items-start">
                <span className="text-accent mr-2 mt-1">•</span>
                <span>Use the mouse wheel to zoom in and out of the graph</span>
              </div>
              <div className="flex items-start">
                <span className="text-accent mr-2 mt-1">•</span>
                <span>Click and drag to pan around the graph</span>
              </div>
              <div className="flex items-start">
                <span className="text-accent mr-2 mt-1">•</span>
                <span>Click on a node to view its details</span>
              </div>
              <div className="flex items-start">
                <span className="text-accent mr-2 mt-1">•</span>
                <span>Use the layout dropdown to change the graph layout</span>
              </div>
              <div className="flex items-start sm:col-span-2">
                <span className="text-accent mr-2 mt-1">•</span>
                <span>Click "Show Analyzer" to extract entities from text</span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
