'use client';

import React, { useEffect, useState } from 'react';
import Link from 'next/link';
import EntityDetail from '@/components/EntityDetail';
import EntityCard from '@/components/EntityCard';
import EntityModal from '@/components/EntityModal';
import TextAnalyzer from '@/components/TextAnalyzer';
import { entityOperations, Entity } from '@/lib/db/supabase';
import { generateEntities, generateRandomEntity } from '@/lib/utils/synthetic-data';
import { NimEntity, NimRelation } from '@/lib/api/nvidia-nim';

export default function EntitiesPage() {
  const [entities, setEntities] = useState<Entity[]>([]);
  const [selectedEntity, setSelectedEntity] = useState<Entity | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [searchTerm, setSearchTerm] = useState('');
  const [filterType, setFilterType] = useState<string | null>(null);
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [isEditModalOpen, setIsEditModalOpen] = useState(false);
  const [entityToEdit, setEntityToEdit] = useState<Omit<Entity, 'id' | 'created_at'> | null>(null);
  const [viewMode, setViewMode] = useState<'list' | 'grid'>('grid');
  const [sortBy, setSortBy] = useState<'name' | 'type' | 'date'>('date');
  const [sortOrder, setSortOrder] = useState<'asc' | 'desc'>('desc');

  // Load entities
  useEffect(() => {
    const loadEntities = async () => {
      try {
        // In a real app, we would fetch from Supabase
        // For demo purposes, we'll generate synthetic data
        const syntheticEntities = generateEntities(15).map((entity, index) => ({
          ...entity,
          id: index.toString(),
          created_at: new Date(Date.now() - Math.random() * 30 * 24 * 60 * 60 * 1000).toISOString() // Random date within last 30 days
        }));
        
        setEntities(syntheticEntities as Entity[]);
        
        // Simulate loading delay
        setTimeout(() => {
          setLoading(false);
        }, 800);
      } catch (err) {
        console.error('Error loading entities:', err);
        setError('Failed to load entities. Please try again.');
        setLoading(false);
      }
    };
    
    loadEntities();
  }, []);

  // Handle entity selection
  const handleEntitySelect = (entity: Entity) => {
    setSelectedEntity(entity);
  };

  // Handle entity creation
  const handleCreateEntity = (newEntity: Omit<Entity, 'id' | 'created_at'>) => {
    const id = (entities.length + 1).toString();
    const createdEntity: Entity = {
      ...newEntity,
      id,
      created_at: new Date().toISOString()
    };
    
    setEntities([...entities, createdEntity]);
    setSelectedEntity(createdEntity);
  };

  // Handle entity update
  const handleUpdateEntity = (updatedEntity: Omit<Entity, 'id' | 'created_at'>) => {
    if (!selectedEntity) return;
    
    const updatedEntities = entities.map(entity => 
      entity.id === selectedEntity.id 
        ? { ...updatedEntity, id: entity.id, created_at: entity.created_at } 
        : entity
    );
    
    setEntities(updatedEntities);
    setSelectedEntity({ ...updatedEntity, id: selectedEntity.id, created_at: selectedEntity.created_at });
  };

  // Handle entity deletion
  const handleDeleteEntity = (entityId: string) => {
    const updatedEntities = entities.filter(entity => entity.id !== entityId);
    setEntities(updatedEntities);
    
    if (selectedEntity && selectedEntity.id === entityId) {
      setSelectedEntity(null);
    }
  };

  // Handle entities extracted from text
  const handleEntitiesExtracted = (extractedEntities: NimEntity[]) => {
    // In a real app, we would add these entities to Supabase
    console.log('Entities extracted:', extractedEntities);
    
    // For demo purposes, we'll create new entities from the extracted entities
    const newEntities = extractedEntities.map((entity, index) => ({
      id: (entities.length + index).toString(),
      name: entity.text,
      type: entity.type || 'Person', // Default to Person if no type is provided
      description: `Extracted entity from text with confidence ${entity.confidence ? Math.round(entity.confidence * 100) : 'unknown'}%`,
      properties: {
        confidence: entity.confidence,
        startIndex: entity.startIndex,
        endIndex: entity.endIndex
      },
      created_at: new Date().toISOString()
    }));
    
    setEntities([...entities, ...newEntities]);
    
    // Show notification
    const notification = document.createElement('div');
    notification.className = 'fixed bottom-4 right-4 bg-green-500 text-white p-4 rounded-lg shadow-lg';
    notification.innerHTML = `Added ${newEntities.length} new entities`;
    document.body.appendChild(notification);
    
    setTimeout(() => {
      notification.remove();
    }, 3000);
  };

  // Handle edit button click
  const handleEditClick = (entity: Entity) => {
    const { id, created_at, ...entityData } = entity;
    setEntityToEdit(entityData);
    setIsEditModalOpen(true);
  };

  // Filter and sort entities
  const filteredAndSortedEntities = entities
    .filter(entity => {
      const matchesSearch = searchTerm === '' || 
        entity.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
        entity.description.toLowerCase().includes(searchTerm.toLowerCase());
      
      const matchesType = filterType === null || entity.type === filterType;
      
      return matchesSearch && matchesType;
    })
    .sort((a, b) => {
      if (sortBy === 'name') {
        return sortOrder === 'asc' 
          ? a.name.localeCompare(b.name)
          : b.name.localeCompare(a.name);
      } else if (sortBy === 'type') {
        return sortOrder === 'asc'
          ? a.type.localeCompare(b.type)
          : b.type.localeCompare(a.type);
      } else { // date
        return sortOrder === 'asc'
          ? new Date(a.created_at).getTime() - new Date(b.created_at).getTime()
          : new Date(b.created_at).getTime() - new Date(a.created_at).getTime();
      }
    });

  // Get unique entity types
  const entityTypes = Array.from(new Set(entities.map(entity => entity.type)));

  // Generate a random entity
  const handleGenerateRandomEntity = () => {
    const randomEntity = generateRandomEntity();
    handleCreateEntity(randomEntity);
  };

  return (
    <div className="w-full">
      <div className="flex flex-wrap justify-between items-center mb-6">
        <div>
          <h1 className="text-2xl font-bold mb-2">Entity Management</h1>
          <p className="text-secondary">
            View and manage entities with NVIDIA NIM integration
          </p>
        </div>
        <div className="flex flex-wrap gap-2 mt-2 sm:mt-0">
          <Link 
            href="/graph"
            className="btn"
          >
            <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4 mr-2" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 5a1 1 0 011-1h14a1 1 0 011 1v2a1 1 0 01-1 1H5a1 1 0 01-1-1V5zM4 13a1 1 0 011-1h6a1 1 0 011 1v6a1 1 0 01-1 1H5a1 1 0 01-1-1v-6zM16 13a1 1 0 011-1h2a1 1 0 011 1v6a1 1 0 01-1 1h-2a1 1 0 01-1-1v-6z" />
            </svg>
            View Graph
          </Link>
        </div>
      </div>

      {error && (
        <div className="card bg-red-900 border-red-800 mb-6">
          <div className="flex items-center">
            <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6 text-red-500 mr-3" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 8v4m0 4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
            </svg>
            <div>
              <h3 className="font-bold text-red-500">Error</h3>
              <p className="text-red-300">{error}</p>
            </div>
          </div>
        </div>
      )}

      <div className="grid grid-cols-1 lg:grid-cols-3 xl:grid-cols-4 gap-4 md:gap-6 w-full">
        <div className="lg:col-span-2 xl:col-span-3 space-y-4 md:space-y-6 w-full">
          <div className="card">
            <div className="card-header">
              <h2 className="card-title">
                <span className="card-title-icon">
                  <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                    <path d="M19 11H5m14 0a2 2 0 012 2v6a2 2 0 01-2 2H5a2 2 0 01-2-2v-6a2 2 0 012-2m14 0V9a2 2 0 00-2-2M5 11V9a2 2 0 012-2m0 0V5a2 2 0 012-2h6a2 2 0 012 2v2M7 7h10"></path>
                  </svg>
                </span>
                Entities
              </h2>
              <div className="flex flex-wrap gap-2">
                <button
                  onClick={() => setIsModalOpen(true)}
                  className="btn btn-primary"
                >
                  <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4 mr-1" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 4v16m8-8H4" />
                  </svg>
                  Add Entity
                </button>
                <button
                  onClick={handleGenerateRandomEntity}
                  className="btn"
                >
                  <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4 mr-1" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 4v5h.582m15.356 2A8.001 8.001 0 004.582 9m0 0H9m11 11v-5h-.581m0 0a8.003 8.003 0 01-15.357-2m15.357 2H15" />
                  </svg>
                  Generate Random
                </button>
                <div className="flex">
                  <button
                    onClick={() => setViewMode('grid')}
                    className={`btn p-2 rounded-r-none ${viewMode === 'grid' ? 'btn-primary' : ''}`}
                    title="Grid view"
                  >
                    <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 6a2 2 0 012-2h2a2 2 0 012 2v2a2 2 0 01-2 2H6a2 2 0 01-2-2V6zM14 6a2 2 0 012-2h2a2 2 0 012 2v2a2 2 0 01-2 2h-2a2 2 0 01-2-2V6zM4 16a2 2 0 012-2h2a2 2 0 012 2v2a2 2 0 01-2 2H6a2 2 0 01-2-2v-2zM14 16a2 2 0 012-2h2a2 2 0 012 2v2a2 2 0 01-2 2h-2a2 2 0 01-2-2v-2z" />
                    </svg>
                  </button>
                  <button
                    onClick={() => setViewMode('list')}
                    className={`btn p-2 rounded-l-none ${viewMode === 'list' ? 'btn-primary' : ''}`}
                    title="List view"
                  >
                    <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 6h16M4 12h16M4 18h16" />
                    </svg>
                  </button>
                </div>
              </div>
            </div>
            
            <div className="filter-bar">
              <div className="filter-search">
                <div className="filter-search-icon">
                  <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z" />
                  </svg>
                </div>
                <input
                  type="text"
                  placeholder="Search entities..."
                  className="form-input filter-search-input"
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                />
              </div>
              <select
                className="form-input filter-dropdown"
                value={filterType || ''}
                onChange={(e) => setFilterType(e.target.value || null)}
              >
                <option value="">All Types</option>
                {entityTypes.map(type => (
                  <option key={type} value={type}>{type}</option>
                ))}
              </select>
              <div className="filter-dropdown">
                <select
                  className="form-input"
                  value={`${sortBy}-${sortOrder}`}
                  onChange={(e) => {
                    const [newSortBy, newSortOrder] = e.target.value.split('-');
                    setSortBy(newSortBy as 'name' | 'type' | 'date');
                    setSortOrder(newSortOrder as 'asc' | 'desc');
                  }}
                >
                  <option value="date-desc">Newest First</option>
                  <option value="date-asc">Oldest First</option>
                  <option value="name-asc">Name (A-Z)</option>
                  <option value="name-desc">Name (Z-A)</option>
                  <option value="type-asc">Type (A-Z)</option>
                  <option value="type-desc">Type (Z-A)</option>
                </select>
              </div>
            </div>
            
            {loading ? (
              <div className="loading py-8">
                <div className="loading-spinner"></div>
                <p>Loading entities...</p>
              </div>
            ) : filteredAndSortedEntities.length > 0 ? (
              viewMode === 'grid' ? (
                <div className="entity-grid w-full">
                  {filteredAndSortedEntities.map(entity => (
                    <EntityCard
                      key={entity.id}
                      entity={entity}
                      selected={selectedEntity?.id === entity.id}
                      onClick={() => handleEntitySelect(entity)}
                      onEdit={() => handleEditClick(entity)}
                      onDelete={() => handleDeleteEntity(entity.id)}
                    />
                  ))}
                </div>
              ) : (
                <div className="entity-list">
                  {filteredAndSortedEntities.map(entity => (
                    <div 
                      key={entity.id}
                      onClick={() => handleEntitySelect(entity)}
                      className={`entity-item ${selectedEntity?.id === entity.id ? 'selected' : ''}`}
                    >
                      <div className="entity-header">
                        <div className="entity-name">{entity.name}</div>
                        <div className="flex gap-2 items-center">
                          <span className={`badge badge-${
                            entity.type === 'Person' ? 'blue' : 
                            entity.type === 'Organization' ? 'red' : 
                            entity.type === 'Location' ? 'yellow' : 
                            entity.type === 'Event' ? 'green' : 
                            entity.type === 'Product' ? 'purple' : ''
                          }`}>
                            {entity.type}
                          </span>
                          <button 
                            onClick={(e) => {
                              e.stopPropagation();
                              handleEditClick(entity);
                            }}
                            className="entity-action-btn"
                            title="Edit entity"
                          >
                            <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15.232 5.232l3.536 3.536m-2.036-5.036a2.5 2.5 0 113.536 3.536L6.5 21.036H3v-3.572L16.732 3.732z" />
                            </svg>
                          </button>
                          <button 
                            onClick={(e) => {
                              e.stopPropagation();
                              handleDeleteEntity(entity.id);
                            }}
                            className="entity-action-btn text-error"
                            title="Delete entity"
                          >
                            <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16" />
                            </svg>
                          </button>
                        </div>
                      </div>
                      <p className="entity-description">
                        {entity.description}
                      </p>
                    </div>
                  ))}
                </div>
              )
            ) : (
              <div className="text-center py-8">
                <svg xmlns="http://www.w3.org/2000/svg" className="h-12 w-12 mx-auto text-secondary mb-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9.172 16.172a4 4 0 015.656 0M9 10h.01M15 10h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
                </svg>
                <p className="text-secondary">No entities found</p>
                <p className="text-xs text-secondary mt-1">Try adjusting your search or filter criteria</p>
                <button
                  onClick={() => setIsModalOpen(true)}
                  className="btn btn-primary mt-4"
                >
                  Add New Entity
                </button>
              </div>
            )}
          </div>
          
          <TextAnalyzer 
            onEntitiesExtracted={handleEntitiesExtracted}
          />
        </div>
        
        <div className="space-y-4 md:space-y-6 w-full">
          <EntityDetail 
            entity={selectedEntity} 
            loading={loading && !selectedEntity}
          />
          
          <div className="card">
            <div className="card-header">
              <h2 className="card-title">
                <span className="card-title-icon">
                  <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                    <path d="M9.663 17h4.673M12 3v1m6.364 1.636l-.707.707M21 12h-1M4 12H3m3.343-5.657l-.707-.707m2.828 9.9a5 5 0 117.072 0l-.548.547A3.374 3.374 0 0014 18.469V19a2 2 0 11-4 0v-.531c0-.895-.356-1.754-.988-2.386l-.548-.547z"></path>
                  </svg>
                </span>
                Quick Tips
              </h2>
            </div>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-sm">
              <div className="flex items-start">
                <span className="text-accent mr-2 mt-1">•</span>
                <span>Use the search box to find entities by name or description</span>
              </div>
              <div className="flex items-start">
                <span className="text-accent mr-2 mt-1">•</span>
                <span>Filter entities by type using the dropdown</span>
              </div>
              <div className="flex items-start">
                <span className="text-accent mr-2 mt-1">•</span>
                <span>Click on an entity to view its details</span>
              </div>
              <div className="flex items-start">
                <span className="text-accent mr-2 mt-1">•</span>
                <span>Use the Text Analyzer to extract entities from text</span>
              </div>
              <div className="flex items-start">
                <span className="text-accent mr-2 mt-1">•</span>
                <span>Add new entities manually or generate random ones</span>
              </div>
              <div className="flex items-start">
                <span className="text-accent mr-2 mt-1">•</span>
                <span>Switch between grid and list views for different layouts</span>
              </div>
            </div>
          </div>
          
          <div className="card">
            <div className="card-header">
              <h2 className="card-title">
                <span className="card-title-icon">
                  <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                    <path d="M11 3.055A9.001 9.001 0 1020.945 13H11V3.055z"></path>
                    <path d="M20.488 9H15V3.512A9.025 9.025 0 0120.488 9z"></path>
                  </svg>
                </span>
                Entity Stats
              </h2>
            </div>
            <div className="graph-stats">
              <div className="stat-item">
                <div className="stat-value">{entities.length}</div>
                <div className="stat-label">Total Entities</div>
              </div>
              <div className="stat-item">
                <div className="stat-value">{entityTypes.length}</div>
                <div className="stat-label">Entity Types</div>
              </div>
              <div className="stat-item">
                <div className="stat-value">{filteredAndSortedEntities.length}</div>
                <div className="stat-label">Filtered</div>
              </div>
            </div>
            
            <div className="mt-4">
              <h4 className="text-sm font-bold text-secondary mb-2">Entity Types:</h4>
              <div className="flex flex-wrap gap-2">
                {entityTypes.map(type => {
                  const count = entities.filter(e => e.type === type).length;
                  return (
                    <div 
                      key={type} 
                      className={`badge badge-${
                        type === 'Person' ? 'blue' : 
                        type === 'Organization' ? 'red' : 
                        type === 'Location' ? 'yellow' : 
                        type === 'Event' ? 'green' : 
                        type === 'Product' ? 'purple' : ''
                      }`}
                      onClick={() => setFilterType(type === filterType ? null : type)}
                      style={{ cursor: 'pointer' }}
                    >
                      {type} ({count})
                    </div>
                  );
                })}
              </div>
            </div>
          </div>
        </div>
      </div>
      
      {/* Add Entity Modal */}
      <EntityModal
        isOpen={isModalOpen}
        onClose={() => setIsModalOpen(false)}
        onSubmit={handleCreateEntity}
        title="Add New Entity"
      />
      
      {/* Edit Entity Modal */}
      <EntityModal
        isOpen={isEditModalOpen}
        onClose={() => setIsEditModalOpen(false)}
        onSubmit={handleUpdateEntity}
        initialData={entityToEdit || undefined}
        isEditing={true}
        title="Edit Entity"
      />
    </div>
  );
}
