# GraphNexus - Knowledge Graph Visualization App

A full-stack application for interactive knowledge graph visualization using Next.js 15, Tailwind CSS, Cytoscape.js, Supabase, Neo4j, and NVIDIA NIM.

## Features

- Interactive knowledge graph visualization with Cytoscape.js
- Entity management with Supabase integration
- Graph database with Neo4j
- Named Entity Recognition and Relation Extraction with NVIDIA NIM
- Synthetic data generation for quick demos

## Tech Stack

- **Frontend:** Next.js 15, Tailwind CSS, Cytoscape.js
- **Backend Database:** Supabase for structured data persistence
- **Knowledge Graph:** Neo4j database for graph relationships
- **AI Inference:** NVIDIA NIM (Inference Microservices for Named Entity Recognition and Relation Extraction)
- **Synthetic Data:** Faker.js for generating realistic test data

## Quick Start

### Prerequisites

- Node.js 18+ and npm
- Supabase account (for production use)
- Neo4j database (for production use)
- NVIDIA NIM API key (for production use)

### Installation

1. Clone the repository:

```bash
git clone https://github.com/yourusername/graphnexus.git
cd graphnexus
```

2. Install dependencies:

```bash
npm install
```

3. Create a `.env.local` file in the root directory with the following environment variables:

```
# Supabase
NEXT_PUBLIC_SUPABASE_URL=your-supabase-url
NEXT_PUBLIC_SUPABASE_ANON_KEY=your-supabase-anon-key

# Neo4j
NEO4J_URI=neo4j://localhost:7687
NEO4J_USER=neo4j
NEO4J_PASSWORD=your-password

# NVIDIA NIM
NEXT_PUBLIC_NIM_API_BASE_URL=https://api.nim.nvidia.com
NIM_API_KEY=your-nim-api-key
```

4. Run the development server:

```bash
npm run dev
```

5. Open [http://localhost:3000](http://localhost:3000) in your browser.

## Setting Up Supabase

1. Create a new Supabase project
2. Create a table called `entities` with the following schema:

```sql
CREATE TABLE entities (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  name TEXT NOT NULL,
  type TEXT NOT NULL,
  description TEXT,
  properties JSONB NOT NULL DEFAULT '{}',
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Create an index on the type column
CREATE INDEX entities_type_idx ON entities (type);
```

3. Update your `.env.local` file with your Supabase URL and anon key

## Setting Up Neo4j

1. Install Neo4j Desktop or use Neo4j Aura (cloud service)
2. Create a new database
3. Run the following Cypher queries to set up constraints:

```cypher
// Create constraints
CREATE CONSTRAINT entity_name IF NOT EXISTS
FOR (e:Entity) REQUIRE e.name IS UNIQUE;

// Create indexes
CREATE INDEX entity_type IF NOT EXISTS
FOR (e:Entity) ON (e.type);
```

4. Update your `.env.local` file with your Neo4j URI, username, and password

## Setting Up NVIDIA NIM

1. Sign up for NVIDIA NIM at [https://www.nvidia.com/en-us/ai-data-science/products/nim/](https://www.nvidia.com/en-us/ai-data-science/products/nim/)
2. Create an API key
3. Update your `.env.local` file with your NIM API key

## Project Structure

```
graphnexus/
├── src/
│   ├── app/                  # Next.js app router
│   │   ├── entities/         # Entity management page
│   │   ├── graph/            # Knowledge graph visualization page
│   │   ├── layout.tsx        # Root layout
│   │   ├── page.tsx          # Home page
│   │   └── globals.css       # Global styles
│   ├── components/           # React components
│   │   ├── EntityDetail.tsx  # Entity detail component
│   │   ├── GraphVisualization.tsx # Cytoscape graph component
│   │   └── TextAnalyzer.tsx  # NVIDIA NIM text analysis component
│   ├── lib/                  # Utility functions and API clients
│   │   ├── api/              # API clients
│   │   │   └── nvidia-nim.ts # NVIDIA NIM API client
│   │   ├── db/               # Database clients
│   │   │   ├── neo4j.ts      # Neo4j database client
│   │   │   └── supabase.ts   # Supabase client
│   │   └── utils/            # Utility functions
│   │       └── synthetic-data.ts # Synthetic data generation
│   └── types/                # TypeScript type definitions
└── public/                   # Static assets
```

## Development Notes

- The application uses synthetic data generation for demo purposes
- In a production environment, you would connect to actual Supabase and Neo4j instances
- The NVIDIA NIM integration includes a fallback mock implementation for demo purposes

## License

MIT
