module.exports = {
  plugins: {},
};
